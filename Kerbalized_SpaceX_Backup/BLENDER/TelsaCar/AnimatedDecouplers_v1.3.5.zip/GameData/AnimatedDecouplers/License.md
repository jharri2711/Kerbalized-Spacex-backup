Released under Creative Commons Share-alike attribution license:

http://creativecommons.org/licenses/by-sa/4.0/

Full convoluted text here:
http://creativecommons.org/licenses/by-sa/4.0/legalcode
